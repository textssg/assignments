package com.airvoice.exceptions;

public class UserDatabaseException extends Exception {
	private static final long serialVersionUID = -9217320675059111924L;
	
	public UserDatabaseException(String message) {
		super(message);
	}
	
	public UserDatabaseException(String message, Throwable cause) {
		super(message, cause);
	}
}
