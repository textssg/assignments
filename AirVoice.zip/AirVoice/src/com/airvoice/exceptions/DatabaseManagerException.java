package com.airvoice.exceptions;

public class DatabaseManagerException extends Exception {
	private static final long serialVersionUID = 3472500257699754698L;
	
	public DatabaseManagerException(String message) {
		super(message);
	}
	
	public DatabaseManagerException(String message, Throwable cause) {
		super(message, cause);
	}
}
