package com.airvoice.core;

import java.util.Date;

public class Tariff {

	private int planId;
	private String planName;
	private boolean planActive;
	private Date planActivationOrDeactivationDate;
	
	private int planActivationFee;
	private int planSecurityDeposit;
	private int monthlyRental;
	
	private int freeLocal;
	private int freeSTD;
	private int freeSMS;

	private int outgoingLocalWithinNetwork; // 		120p/min (2p/sec)
	private int outgoingLocalOutsideNetworkMobile;// 120p/min (2p/sec)
	private int outgoingLocalOutsideNetworkLandline;//120p/min	(2p/sec)
	private int outgoingSTD; //2p/sec
	private int outgoingISD; //	usa 8rs/min
	private int outgoingLocalRoamingNational; //0.8/min
	private int outgoingSTDRoamingNational;  //1.15/min
	private int incomingNormal; //free
	private int incomingNationalRoaming; //0.45p/min

	

	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public void setPlanActive(boolean planActive) {
		this.planActive = planActive;
	}
	public void setPlanActivationOrDeactivationDate(Date planActivationOrDeactivationDate) {
		this.planActivationOrDeactivationDate = planActivationOrDeactivationDate;
	}
	public void setPlanActivationFee(int planActivationFee) {
		this.planActivationFee = planActivationFee;
	}
	public void setPlanSecurityDeposit(int planSecurityDeposit) {
		this.planSecurityDeposit = planSecurityDeposit;
	}
	public void setMonthlyRental(int monthlyRental) {
		this.monthlyRental = monthlyRental;
	}
	public void setFreeLocal(int freeLocal) {
		this.freeLocal = freeLocal;
	}
	public void setFreeSTD(int freeSTD) {
		this.freeSTD = freeSTD;
	}
	public void setFreeSMS(int freeSMS){
		this.freeSMS=freeSMS;
	}
	
	
	public void setOutgoingLocalWithinNetwork(int outgoingLocalWithinNetwork) {
		this.outgoingLocalWithinNetwork = outgoingLocalWithinNetwork;
	}
	public void setOutgoingLocalOutsideNetworkMobile(int outgoingLocalOutsideNetworkMobile) {
		this.outgoingLocalOutsideNetworkMobile = outgoingLocalOutsideNetworkMobile;
	}
	public void setOutgoingLocalOutsideNetworkLandline(int outgoingLocalOutsideNetworkLandline) {
		this.outgoingLocalOutsideNetworkLandline = outgoingLocalOutsideNetworkLandline;
	}
	public void setOutgoingSTD(int outgoingSTD) {
		this.outgoingSTD = outgoingSTD;
	}
	public void setOutgoingISD(int outgoingISD) {
		this.outgoingISD = outgoingISD;
	}
	public void setOutgoingLocalRoamingNational(int outgoingLocalRoamingNational) {
		this.outgoingLocalRoamingNational = outgoingLocalRoamingNational;
	}
	public void setOutgoingSTDRoamingNational(int outgoingSTDRoamingNational) {
		this.outgoingSTDRoamingNational = outgoingSTDRoamingNational;
	}
	
	public void setIncomingNormal(int incomingNormal) {
		this.incomingNormal = incomingNormal;
	}
	public void setIncomingNationalRoaming(int incomingNationalRoaming) {
		this.incomingNationalRoaming = incomingNationalRoaming;
	}
	
	public int getPlanId() {
		return planId;
	}
	public String getPlanName() {
		return planName;
	}
	public boolean isPlanActive() {
		return planActive;
	}
	public Date getPlanActivationOrDeactivationDate() {
		return planActivationOrDeactivationDate;
	}
	public int getPlanActivationFee() {
		return planActivationFee;
	}
	public int getPlanSecurityDeposit() {
		return planSecurityDeposit;
	}
	public int getMonthlyRental() {
		return monthlyRental;
	}
	public int getFreeLocal() {
		return freeLocal;
	}
	public int getFreeSTD() {
		return freeSTD;
	}
	public int getFreeSMS() {
		return freeSMS;
	}
	
	public int getOutgoingLocalWithinNetwork() {
		return outgoingLocalWithinNetwork;
	}
	public int getOutgoingLocalOutsideNetworkMobile() {
		return outgoingLocalOutsideNetworkMobile;
	}
	public int getOutgoingLocalOutsideNetworkLandline() {
		return outgoingLocalOutsideNetworkLandline;
	}
	public int getOutgoingSTD() {
		return outgoingSTD;
	}
	public int getOutgoingISD() {
		return outgoingISD;
	}
	public int getOutgoingLocalRoamingNational() {
		return outgoingLocalRoamingNational;
	}
	public int getOutgoingSTDRoamingNational() {
		return outgoingSTDRoamingNational;
	}

	public int getIncomingNormal() {
		return incomingNormal;
	}
	public int getIncomingNationalRoaming() {
		return incomingNationalRoaming;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + freeLocal;
		result = prime * result + freeSMS;
		result = prime * result + freeSTD;
		result = prime * result + incomingNationalRoaming;
		result = prime * result + incomingNormal;
		result = prime * result + monthlyRental;
		result = prime * result + outgoingISD;
		result = prime * result + outgoingLocalOutsideNetworkLandline;
		result = prime * result + outgoingLocalOutsideNetworkMobile;
		result = prime * result + outgoingLocalRoamingNational;
		result = prime * result + outgoingLocalWithinNetwork;
		result = prime * result + outgoingSTD;
		result = prime * result + outgoingSTDRoamingNational;
		result = prime * result + planActivationFee;
		result = prime
				* result
				+ ((planActivationOrDeactivationDate == null) ? 0
						: planActivationOrDeactivationDate.hashCode());
		result = prime * result + (planActive ? 1231 : 1237);
		result = prime * result
				+ ((planName == null) ? 0 : planName.hashCode());
		result = prime * result + planSecurityDeposit;
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Tariff)) {
			return false;
		}
		Tariff other = (Tariff) obj;
		if (freeLocal != other.freeLocal) {
			return false;
		}
		if (freeSMS != other.freeSMS) {
			return false;
		}
		if (freeSTD != other.freeSTD) {
			return false;
		}
		if (incomingNationalRoaming != other.incomingNationalRoaming) {
			return false;
		}
		if (incomingNormal != other.incomingNormal) {
			return false;
		}
		if (monthlyRental != other.monthlyRental) {
			return false;
		}
		if (outgoingISD != other.outgoingISD) {
			return false;
		}
		if (outgoingLocalOutsideNetworkLandline != other.outgoingLocalOutsideNetworkLandline) {
			return false;
		}
		if (outgoingLocalOutsideNetworkMobile != other.outgoingLocalOutsideNetworkMobile) {
			return false;
		}
		if (outgoingLocalRoamingNational != other.outgoingLocalRoamingNational) {
			return false;
		}
		if (outgoingLocalWithinNetwork != other.outgoingLocalWithinNetwork) {
			return false;
		}
		if (outgoingSTD != other.outgoingSTD) {
			return false;
		}
		if (outgoingSTDRoamingNational != other.outgoingSTDRoamingNational) {
			return false;
		}
		if (planActivationFee != other.planActivationFee) {
			return false;
		}
		if (planActivationOrDeactivationDate == null) {
			if (other.planActivationOrDeactivationDate != null) {
				return false;
			}
		} else if (!planActivationOrDeactivationDate
				.equals(other.planActivationOrDeactivationDate)) {
			return false;
		}
		if (planActive != other.planActive) {
			return false;
		}
		if (planName == null) {
			if (other.planName != null) {
				return false;
			}
		} else if (!planName.equals(other.planName)) {
			return false;
		}
		if (planSecurityDeposit != other.planSecurityDeposit) {
			return false;
		}
		return true;
	}
	
}