package com.airvoice.core;

import java.util.Date;

import com.airvoice.constants.CallDetail;
import com.airvoice.constants.CallType;
import com.airvoice.exceptions.DatabaseManagerException;
import com.airvoice.exceptions.UserDatabaseException;

public class CallRecord implements Comparable {
	private int callId;
	private int customerId;
	private Customer customer;
	/*! Determine in constructor  by looking at the planName from customer table, 
	 * and then getting the planId from Tariff plan mapping table
	 */
	private int planId;
	private int fromMobileNumber;
	private int toMobileNumber;
	private Date fromDateAndTime;
	private Date toDateAndTime;
	private CallType callType;
	private CallDetail callDetail;
	private int duration;
	
	public CallRecord(long mobileNumber, int fromMobileNumber, int toMobileNumber,
			Date fromDateAndTime, Date toDateAndTime, CallType callType,
			CallDetail callDetail) 
					throws UserDatabaseException, DatabaseManagerException {
		this.fromMobileNumber = fromMobileNumber;
		this.toMobileNumber = toMobileNumber;
		this.fromDateAndTime = fromDateAndTime;
		this.toDateAndTime = toDateAndTime;
		this.callType = callType;
		this.callDetail = callDetail;
		
		/* Step1: Get the customer object by using
		 * CustomerDB.dbGetCustomerUsingCustomerMobile(mobileNumber)
		 */
		
		/*
		 * Step 2: Check if the customer is active. If he/she has been
		 * deactivated, return a UserDatabaseException saying that the
		 * customer has been deactivated.
		 */
		
		/* Step 3: From the customer object obtained, set the customerId
		 * instance variable and set the customer instance variable.
		 */
	}
	
	public CallRecord(int customerId, int fromMobileNumber, int toMobileNumber,
			Date fromDateAndTime, Date toDateAndTime, CallType callType,
			CallDetail callDetail) 
					throws UserDatabaseException, DatabaseManagerException {
		this.fromMobileNumber = fromMobileNumber;
		this.toMobileNumber = toMobileNumber;
		this.fromDateAndTime = fromDateAndTime;
		this.toDateAndTime = toDateAndTime;
		this.callType = callType;
		this.callDetail = callDetail;
		
		/* Step1: Get the customer object by using
		 * CustomerDB.dbGetCustomerUsingCustomerId(customerId)
		 */
		
		/*
		 * Step 2: Check if the customer is active. If he/she has been
		 * deactivated, return a UserDatabaseException saying that the
		 * customer has been deactivated.
		 */
		
		/* Step3: From the customer object obtained, set the customerId
		 * instance variable and set the customer instance variable.
		 */
	}
	
	/*
	 * Called in the Servlet during insertion of a call. During getting
	 * of a call record from database, this function should not invoked 
	 * and instead setPlanId must be used with the plan Id coming from
	 * the database. Because at the time of the getting the call record,
	 * the plan id associated with the plan name would have changed. But
	 * the customer would have placed that particular call on a different
	 * plan id.
	 */
	public void determinePlanId() {
		/* Get the planName from the customer object.
		 * Get the planId by using TariffDB.dbGetPlanIdFromPlanName instance
		 * variable. Set the planId instance variable. 
		 */
	}
	
	/*! Get duration of the call in seconds. Computed as a difference between toDateAndTime
	 * and fromDateAndTime
	 */
	public int computeDuration() {
		/* TODO: Compute the duration */
		return this.duration;
	}
	
	@Override
	public int compareTo(Object o) {
		/* Use fromDateAndTime for sorting the call records */
		return 0;
	}
	
	/**
	 * @return the callId
	 */
	protected int getCallId() {
		return callId;
	}
	/**
	 * @return the customerId
	 */
	protected int getCustomerId() {
		return customerId;
	}
	/**
	 * @return the planId
	 */
	protected int getPlanId() {
		return planId;
	}
	/**
	 * @return the fromMobileNumber
	 */
	protected int getFromMobileNumber() {
		return fromMobileNumber;
	}
	/**
	 * @return the toMobileNumber
	 */
	protected int getToMobileNumber() {
		return toMobileNumber;
	}
	/**
	 * @return the fromDateAndTime
	 */
	protected Date getFromDateAndTime() {
		return fromDateAndTime;
	}
	/**
	 * @return the toDateAndTime
	 */
	protected Date getToDateAndTime() {
		return toDateAndTime;
	}
	/**
	 * @return the callType
	 */
	protected CallType getCallType() {
		return callType;
	}
	/**
	 * @return the callDetail
	 */
	protected CallDetail getCallDetail() {
		return callDetail;
	}
	/**
	 * @return the duration
	 */
	protected int getDuration() {
		return duration;
	}
	/**
	 * @param callId the callId to set
	 */
	protected void setCallId(int callId) {
		this.callId = callId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	protected void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	/**
	 * @param planId the planId to set
	 */
	protected void setPlanId(int planId) {
		this.planId = planId;
	}
	/**
	 * @param fromMobileNumber the fromMobileNumber to set
	 */
	protected void setFromMobileNumber(int fromMobileNumber) {
		this.fromMobileNumber = fromMobileNumber;
	}
	/**
	 * @param toMobileNumber the toMobileNumber to set
	 */
	protected void setToMobileNumber(int toMobileNumber) {
		this.toMobileNumber = toMobileNumber;
	}
	/**
	 * @param fromDateAndTime the fromDateAndTime to set
	 */
	protected void setFromDateAndTime(Date fromDateAndTime) {
		this.fromDateAndTime = fromDateAndTime;
	}
	/**
	 * @param toDateAndTime the toDateAndTime to set
	 */
	protected void setToDateAndTime(Date toDateAndTime) {
		this.toDateAndTime = toDateAndTime;
	}
	/**
	 * @param callType the callType to set
	 */
	protected void setCallType(CallType callType) {
		this.callType = callType;
	}
	/**
	 * @param callDetail the callDetail to set
	 */
	protected void setCallDetail(CallDetail callDetail) {
		this.callDetail = callDetail;
	}
	/**
	 * @param duration the duration to set
	 */
	protected void setDuration(int duration) {
		this.duration = duration;
	}
}
