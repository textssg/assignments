package com.airvoice.core;

public class SmsRecord {

}
