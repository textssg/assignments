package com.airvoice.core;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.Random;

public class Customer {
	private int customerId;
	private long mobileNumber;
	private String name;
	private String address;
	private int pincode;
	private String tariffPlanName;
	private boolean subsciptionActive;
	private Date activationDate;
	private Date deactivationDate;
	
	
	public Customer(){}
	
	public Customer(String name, String address, int pincode, String planName){
		this.name=name;
		this.address=address;
		this.pincode=pincode;
		this.tariffPlanName=planName;
	}
	
	public long allocateMobileNumber(int prefix){
		if (prefix < 100 || prefix >999) {
			// Not a 3 digit prefix as expected
			// Have a default prefix
			prefix = 612;
		}
		
		// TODO: Validate if a mobile number already exists
		// We can use CustomerDB.dbGetCustomerUsingMobileNumber for this purpose.
		// If the arraylist is empty, we are good to go. Otherwise, the number
		// may be in use / the customer might have been deactivated. Either way,
		// we can generate another numnber. (i.e.) we don't bother about reusing
		// deactivated mobile numbers for now. 
		// Loop until a valid mobile number is obtained
		long last7digits = (long) (Math.random() * 10000000L);
		long mobileNumber = (prefix * 10000000L) + last7digits;
		return mobileNumber;
        /*Random rand = new Random();
        int num1 = 612;
        int num2 = rand.nextInt(1000);
        int num3 = rand.nextInt(1000);
        DecimalFormat df3 = new DecimalFormat("0000"); // 3 zeros
        String phoneNumber = num1  + df3.format(num2) + df3.format(num3);
       System.out.println(phoneNumber);*/
      //this.mobileNumber=Integer.parseInt(phoneNumber.trim());
	}

	/**
	 * @return the customerId
	 */
	protected int getCustomerId() {
		return customerId;
	}

	/**
	 * @return the mobileNumber
	 */
	protected long getMobileNumber() {
		return mobileNumber;
	}

	/**
	 * @return the name
	 */
	protected String getName() {
		return name;
	}

	/**
	 * @return the address
	 */
	protected String getAddress() {
		return address;
	}

	/**
	 * @return the pincode
	 */
	protected int getPincode() {
		return pincode;
	}

	/**
	 * @return the tariffPlanName
	 */
	protected String getTariffPlanName() {
		return tariffPlanName;
	}

	/**
	 * @return the subsciptionActive
	 */
	protected boolean isSubsciptionActive() {
		return subsciptionActive;
	}

	/**
	 * @return the activationDate
	 */
	protected Date getActivationDate() {
		return activationDate;
	}

	/**
	 * @return the deactivationDate
	 */
	protected Date getDeactivationDate() {
		return deactivationDate;
	}

	/**
	 * @param customerId the customerId to set
	 */
	protected void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	protected void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	/**
	 * @param name the name to set
	 */
	protected void setName(String name) {
		this.name = name;
	}

	/**
	 * @param address the address to set
	 */
	protected void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @param pincode the pincode to set
	 */
	protected void setPincode(int pincode) {
		this.pincode = pincode;
	}

	/**
	 * @param tariffPlanName the tariffPlanName to set
	 */
	protected void setTariffPlanName(String tariffPlanName) {
		this.tariffPlanName = tariffPlanName;
	}

	/**
	 * @param subsciptionActive the subsciptionActive to set
	 */
	protected void setSubsciptionActive(boolean subsciptionActive) {
		this.subsciptionActive = subsciptionActive;
	}

	/**
	 * @param activationDate the activationDate to set
	 */
	protected void setActivationDate(Date activationDate) {
		this.activationDate = activationDate;
	}

	/**
	 * @param deactivationDate the deactivationDate to set
	 */
	protected void setDeactivationDate(Date deactivationDate) {
		this.deactivationDate = deactivationDate;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + (int) mobileNumber;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + pincode;
		result = prime * result
				+ ((tariffPlanName == null) ? 0 : tariffPlanName.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof Customer)) {
			return false;
		}
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null) {
				return false;
			}
		} else if (!address.equals(other.address)) {
			return false;
		}
		if (mobileNumber != other.mobileNumber) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		} else if (!name.equals(other.name)) {
			return false;
		}
		if (pincode != other.pincode) {
			return false;
		}
		if (tariffPlanName == null) {
			if (other.tariffPlanName != null) {
				return false;
			}
		} else if (!tariffPlanName.equals(other.tariffPlanName)) {
			return false;
		}
		return true;
	}
}