package com.airvoice.constants;

public enum CallType {
	INCOMING,
	OUTGOING,
}
