package com.airvoice.test;

import java.util.Date;

import com.airvoice.core.Tariff;
import com.airvoice.db.TariffDB;
import com.airvoice.exceptions.DatabaseManagerException;
import com.airvoice.exceptions.UserDatabaseException;

public class TariffDBTest {

	
	static Tariff formTariffObject1(String planName) {
		Tariff tf=new Tariff();
		tf.setPlanName(planName);
		tf.setPlanActive(true);
		tf.setPlanActivationOrDeactivationDate(new Date());
		tf.setPlanActivationFee(500);
		tf.setPlanSecurityDeposit(100);
		tf.setMonthlyRental(499);
		tf.setFreeLocal(200);
		tf.setFreeSTD(200);
		tf.setFreeSMS(500);
		tf.setOutgoingLocalWithinNetwork(1);
		tf.setOutgoingLocalOutsideNetworkMobile(1);
		tf.setOutgoingLocalOutsideNetworkLandline(1);
		tf.setOutgoingSTD(1);
		tf.setOutgoingISD(1);
		tf.setOutgoingLocalRoamingNational(1);
		tf.setOutgoingSTDRoamingNational(1);
		tf.setIncomingNormal(1);
		tf.setIncomingNationalRoaming(1);
		return tf;
	}
	
	static Tariff formTariffObject2(String planName) {
		Tariff tf=new Tariff();
		tf.setPlanName(planName);
		tf.setPlanActive(true);
		tf.setPlanActivationOrDeactivationDate(new Date());
		tf.setPlanActivationFee(600);
		tf.setPlanSecurityDeposit(100);
		tf.setMonthlyRental(499);
		tf.setFreeLocal(800);
		tf.setFreeSTD(200);
		tf.setFreeSMS(500);
		tf.setOutgoingLocalWithinNetwork(1);
		tf.setOutgoingLocalOutsideNetworkMobile(1);
		tf.setOutgoingLocalOutsideNetworkLandline(1);
		tf.setOutgoingSTD(1);
		tf.setOutgoingISD(1);
		tf.setOutgoingLocalRoamingNational(1);
		tf.setOutgoingSTDRoamingNational(1);
		tf.setIncomingNormal(1);
		tf.setIncomingNationalRoaming(1);
		return tf;
	}
	
	static int testDbInsertTariff(String planName) throws UserDatabaseException, DatabaseManagerException{
		Tariff tf = TariffDBTest.formTariffObject1(planName);
		int planID = TariffDB.dbInsertTariff(tf);
		return planID;
	}
	
	static boolean testGetPlanIdFromPlanName(String planName, int expectedPlanID) {
		return false; // TODO
	}
	
	static boolean testDbGetTariffFromPlanId(int planId, Tariff expectedTariffObj) {
		return false; // TODO
	}
	
	static boolean testDbGetTariffFromPlanName(String planName, Tariff expectedTariffObj) {
		return false; // TODO
	}
	
	static int testDbUpdateTariff(String planName) {
		return 0; // Return the updated plan id
	}
	
	public static void main(String[] args){
		try {
			int planID = testDbInsertTariff("Red_599");
			System.out.println("Obtained Plan ID for insertion is = " + planID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
