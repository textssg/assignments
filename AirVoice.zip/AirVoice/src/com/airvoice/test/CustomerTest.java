package com.airvoice.test;

import com.airvoice.core.Customer;

public class CustomerTest {

	public static long testAllocateMobileNumber(int prefix) {
		Customer cus = new Customer();
		return (cus.allocateMobileNumber(prefix));
	}
	public static void main(String[] args) {
		System.out.println(CustomerTest.testAllocateMobileNumber(612));
	}

}
