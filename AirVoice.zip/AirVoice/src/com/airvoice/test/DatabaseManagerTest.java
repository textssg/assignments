package com.airvoice.test;

import java.util.HashMap;

import com.airvoice.db.DatabaseManager;
import com.airvoice.exceptions.DatabaseManagerException;

public class DatabaseManagerTest {

	public static void insertTableTest() throws DatabaseManagerException{
		DatabaseManager db=new DatabaseManager("jdbc:oracle:thin:@localhost:1521:xe","system","Scholar","oracle.jdbc.driver.OracleDriver");
		db.open();
		String id="id";
		String name="name";
		String a="'kumar'";
		
		HashMap<String,String> fieldNameValue=new HashMap<String,String>();
		fieldNameValue.put(id, "4");
		fieldNameValue.put(name,a);
		db.insertIntoTable("shiva_try", fieldNameValue, null);
		db.close();
		
	}
	public static void main(String[] args) {
		try {
			insertTableTest();
		} catch (DatabaseManagerException e) {
			e.printStackTrace();
		}	
	}

}