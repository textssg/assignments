package com.airvoice.db;

import java.util.ArrayList;
import java.util.Date;

import com.airvoice.core.CallRecord;
import com.airvoice.core.Customer;
import com.airvoice.exceptions.DatabaseManagerException;
import com.airvoice.exceptions.UserDatabaseException;

public class CallRecordDB {
	public static void dbInsertCall(CallRecord record) 
			throws UserDatabaseException, DatabaseManagerException {
		/* Insert the call record into the 'CallRecord' table
		 * by using DatabaseManager.getPreparedStatementForInsert()
		 */
	}
	
	/*
	 * Get all the call records of the customer
	 */
	public static ArrayList<CallRecord> dbGetCallRecordsOfCustomer(int customerId) 
			throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Select all records for the customer from the 'CallRecord' table.
		 * If there are no call records, throw a UserDatabaseException saying
		 * the customer has not placed any call. 
		 * 
		 * Where clause would just have the customer_id. 
		 * 
		 * From the obtained records, for each record form the CallRecord and
		 * add to an array list.
		 */
		return null; /* TODO */
	}
	
	/*
	 * Get call records of the customer within a specified time period.
	 */
	public static ArrayList<CallRecord> dbGetCallRecordsOfCustomer(int customerId,
			Date startTime, Date endTime) 
			throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Select all records for the customer from the 'CallRecord' table.
		 * If there are no call records, throw a UserDatabaseException saying
		 * the customer has not placed any call. 
		 * 
		 * Where clause we need to do something like 
		 * fromDateAndTime >= startTime && toDateAndTime <= endTime
		 * 
		 * From the obtained records, for each record form the CallRecord and
		 * add to an array list.
		 */
		return null; /* TODO */
	}
}
