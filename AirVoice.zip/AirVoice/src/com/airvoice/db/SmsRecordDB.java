package com.airvoice.db;

public class SmsRecordDB {

}
