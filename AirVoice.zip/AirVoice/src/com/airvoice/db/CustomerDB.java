package com.airvoice.db;

import java.util.ArrayList;

import com.airvoice.core.Customer;
import com.airvoice.exceptions.DatabaseManagerException;
import com.airvoice.exceptions.UserDatabaseException;

public class CustomerDB {

	/*!
	 * Function: dbInsertCustomer
	 * 
	 * Insert a new customer into the database
	 */
	public static int dbInsertCustomer(Customer customer) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step1: Check if the the mobile number passed already exists
		 * We can use the the CustomerDB.dbGetCustomerUsingMobileNumber
		 * for this purpose. If the returned value is null we are good
		 * to go. Otherwise throw an UserDatabaseException saying mobile number
		 * already in use. 
		 */
		
		/*
		 * Step 2: Insert the customer into the database. Similar to
		 * TariffDB.insertTariff(). Use getPreparedStatement and set the fields. 
		 */
		
		/*
		 * Step 3: Get the customer auto-generated using oracle. Similar to TariffDB. 
		 * Return the customer id. 
		 */
		return 0;
	}
	
	public static void dbUpdateCustomer(Customer customer) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step1: Get the existing customer java object using CustomerDB.dbGetCustomerUsingMobileNumber
		 */
		
		/*
		 * Step2: If the obtained db customer object is not equal to passed customer object.
		 * Use .equals() for this purpose. if they are same, not update has happened. Return a UserDatabaseException
		 * saying no field got changed / nothing to update.
		 * 
		 * Note: Fields that are capable of updating in this method by the user/servlet are:
		 *  - Address
		 *  - Name
		 *  - Pincode
		 */
		
		/*
		 * Step3: Update the Customer record by using DatabaseManager.updateInTable() with where clause containing the
		 * customer id. 
		 */
	}
	
	public static void dbUpdateCustomerMobile(int oldMobileNumber, int newMobileNumber) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step1: Get the existing customer java object using CustomerDB.dbGetCustomerUsingMobileNumber(oldMobileNumber)
		 */
		
		/*
		 * Step2: Check if the newMobileNumber is in use by anybody using CustomerDB.dbGetCustomerUsingMobileNumber(newMobileNumber)
		 * If in use, return userDatabaseException saying new mobile number already in use. 
		 */
		
		/*
		 * Step3: Update the mobile number for the customer. We can use DatabaseManager.updateInTable() with where clause containing
		 * the customer id
		 */
	}
	
	public static void dbDeleteCustomer (Customer customer) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step1: Get the existing customer java object using CustomerDB.dbGetCustomerUsingMobileNumber(oldMobileNumber)
		 */
		
		/*
		 * Step2: Delete the customer using DatabaseManager.deleteInTable()
		 * You can use customer id in the where clause
		 * Note: Make sure on cascade delete is set up for all tables that use customer id as foreign key
		 */
		
	}
	
	public static void dbActivateCustomer (Customer customer) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step 1: Get the existing customer java object using CustomerDB.dbGetCustomerUsingMobileNumber(oldMobileNumber)
		 */
		
		/*
		 * Step 2: Check of the current subscription status in inactive (i.e) false. Otherwise throw UserDatabaseException saying
		 * customer already activated. 
		 */
		/*
		 * Step 3: Update the customer record with subscription status as inactive (i.e.) false and update the
		 * activation date. Use DatabaseManager.getPreparedStatementForUpdate() as we are going to update
		 * the timestamp. We can use the customer id in the where clause. 
		 */
	}
	
	public static void dbDeactivateCustomer(Customer customer) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step 1: Get the existing customer java object using CustomerDB.dbGetCustomerUsingMobileNumber(oldMobileNumber)
		 */
		
		/*
		 * Step 2: Check of the current subscription status in active (i.e) true. Otherwise throw UserDatabaseException saying
		 * customer already deactivated. 
		 */
		
		/*
		 * Step 3: Update the customer record with subsription status as inactive (i.e.) false and update the
		 * de-activation date. Use DatabaseManager.getPreparedStatementForUpdate() as we are going to update
		 * the timestamp. We can use the customer id in the where clause. 
		 */
	}
	
	public static Customer dbGetCustomerUsingCustomerID (int customerID) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step1: Check if the customer id exists in the database. Otherwise throw a UserDatabaseException saying
		 * customer does not exist. We can use DatabaseManager.selectAll for this.
		 */
		
		/*
		 * Step 2: From the obtained record, form the customer object and return to the caller.
		 */
		return null; // TODO: Return the actual customer object
	}
	
	public static Customer dbGetCustomerUsingMobileNumber(int mobileNumber) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step1: Check if the mobile number exists in the database. Otherwise throw a UserDatabaseException saying
		 * customer does not exist. We can use DatabaseManager.selectAll for this.
		 */
		
		/*
		 * Step 2: From the obtained record, form the customer object and return to the caller.
		 */
		return null; // TODO: Return the actual customer object
	}
	
	public static ArrayList<Customer> dbGetCustomerUsingName (String name) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step1: Check if the name exists in the database. Otherwise throw a UserDatabaseException saying
		 * customer does not exist. We can use DatabaseManager.selectAll for this.
		 */
		
		/*
		 * Step 2: From the obtained record(s), form the customer object and return to the caller.
		 * Since there could be more than one record, use array list.
		 */
		return null; // TODO: Return the actual customer object
	}
	
	public static ArrayList<Customer> dbGetCustomerUsingAddress(String address, int pincode) throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Step1: Check if the address exists in the database. Otherwise throw a UserDatabaseException saying
		 * customer does not exist. We can use DatabaseManager.selectAll for this.
		 */
		
		/*
		 * Step 2: From the obtained record(s), form the customer object and return to the caller.
		 * Since there could be more than one record, use array list.
		 */
		return null; // TODO: Return the actual customer object
	}
}