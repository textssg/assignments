package com.airvoice.db;

import java.util.ArrayList;
import java.util.Date;

import com.airvoice.core.CallRecord;
import com.airvoice.core.CustomerBill;
import com.airvoice.exceptions.DatabaseManagerException;
import com.airvoice.exceptions.UserDatabaseException;

public class CustomerBillDB {
	public static void dbInsertBill(CustomerBill bill) 
			throws UserDatabaseException, DatabaseManagerException {
		/* Insert the bill into the 'CustomerBill' table
		 * by using DatabaseManager.getPreparedStatementForInsert()
		 */
	}
	
	/*
	 * Get all the bill records of the customer
	 */
	public static ArrayList<CustomerBill> dbGetBillsOfCustomer(int customerId) 
			throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Select all records for the customer from the 'CustomerBill' table.
		 * If there are no bills, throw a UserDatabaseException saying
		 * no bill has been generated for the customer.
		 * 
		 * Where clause would just have the customer_id. 
		 * 
		 * From the obtained records, for each record form the CustomerBill and
		 * add to an array list.
		 */
		return null; /* TODO */
	}
	
	/*
	 * Get bill records of the customer within a specified time period.
	 */
	public static ArrayList<CustomerBill> dbGetBillsOfCustomer(int customerId,
			Date startTime, Date endTime) 
			throws UserDatabaseException, DatabaseManagerException {
		/*
		 * Select all records for the customer from the 'BillRecord' table.
		 * If there are no bills, throw a UserDatabaseException saying
		 * no bill has been generated for the customer.
		 * 
		 * Where clause we need to do something like 
		 * fromDateAndTime >= billingDateAndTime && toDateAndTime <= billingDateAndTime
		 * 
		 * NOTE: this is the billing date & time and not the start date and time of
		 * these bills.
		 * 
		 * From the obtained records, for each record form the CustomerBill and
		 * add to an array list.
		 */
		return null; /* TODO */
	}
}
